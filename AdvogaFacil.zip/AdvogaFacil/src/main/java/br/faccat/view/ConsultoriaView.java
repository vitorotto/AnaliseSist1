package br.faccat.view;

public class ConsultoriaView {
}
