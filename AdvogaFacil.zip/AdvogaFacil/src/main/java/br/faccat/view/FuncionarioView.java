package br.faccat.view;

public class FuncionarioView {
}
