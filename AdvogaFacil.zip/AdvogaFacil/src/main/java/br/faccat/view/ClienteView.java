package br.faccat.view;

public class ClienteView {
}
