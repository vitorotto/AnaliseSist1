package br.faccat.repository;

public class ClientesRepository {
}
