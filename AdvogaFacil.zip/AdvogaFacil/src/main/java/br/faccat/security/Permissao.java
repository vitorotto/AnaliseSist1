package br.faccat.security;

public class Permissao {
}
