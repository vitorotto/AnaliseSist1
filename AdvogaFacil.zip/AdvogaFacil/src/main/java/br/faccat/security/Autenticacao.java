package br.faccat.security;

public class Autenticacao {
}
