package br.faccat.service;

public class NotificacaoService {
}
