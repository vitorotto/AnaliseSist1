package br.faccat.service;

public class AgendamentoService {
}
