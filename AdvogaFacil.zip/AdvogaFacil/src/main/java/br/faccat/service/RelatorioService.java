package br.faccat.service;

public class RelatorioService {
}
