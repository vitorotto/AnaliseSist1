package br.faccat.model;

public class Processo {
    public String codProcesso;

    public Processo(String codProcesso) {
        this.codProcesso = codProcesso;
    }

    public String getCodProcesso() {
        return codProcesso;
    }
}
