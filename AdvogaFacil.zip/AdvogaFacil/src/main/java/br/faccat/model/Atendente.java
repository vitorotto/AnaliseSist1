package br.faccat.model;


public class Atendente {
    public void autenticar(String senhaFornecida) {
    }

    public void getEmail() {
    }
}
