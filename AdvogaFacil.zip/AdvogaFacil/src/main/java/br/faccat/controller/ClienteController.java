package br.faccat.controller;

public class ClienteController {
}
