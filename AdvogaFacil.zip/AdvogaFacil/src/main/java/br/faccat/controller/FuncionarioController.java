package br.faccat.controller;

public class FuncionarioController {
}
