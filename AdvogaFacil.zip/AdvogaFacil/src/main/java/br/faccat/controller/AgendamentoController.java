package br.faccat.controller;

public class AgendamentoController {
}
