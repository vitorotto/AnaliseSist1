package br.faccat.controller;

public class ConsultoriaController {
}
